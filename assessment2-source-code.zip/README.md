Undestanding basic git and github 

Getting changes from github 

--> Terminal :git pull
--> GitHub Deskptop : fetch origin button git pull button 


Pushing changes to github

--> Terminal 
Step 1:
  git add <filename>  { to add a specific file }
  OR 
  git add . { to add all files }
  
Step 2:
  git commit -m"Add your commit message"
  
Step 3: 
  git pull
  
  
Branches: 
 git checkout <branchname> --> move to branch called branchname
 git checkout -b <branchname> --> Create branch called branchname and move to it 
>>>>>>> 5758ce3c166afda67596835f4d57ff2ab5733860
