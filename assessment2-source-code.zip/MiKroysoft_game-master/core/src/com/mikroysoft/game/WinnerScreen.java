package com.mikroysoft.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

/**
 * Shown when the user wins the game, holds a button to return to the menu.
 */
public class WinnerScreen implements Screen {
    private Game game;
    private Texture buttonTexture;
    private TextureRegion textureRegion;
    private TextureRegionDrawable textureRegionDrawable;
    private ImageButton exitButton;
    private Stage stage;
    private BitmapFont font;
    private Label outcomeTitle;
    private Label menuButtonLabel;

    public WinnerScreen(final Game game){
        this.game = game;
        font = new BitmapFont();

        //setting label
        Label.LabelStyle labelStyle = makeLabelStyle(Color.WHITE);
        //alternative text style
        Label.LabelStyle labelStyle2 = makeLabelStyle(Color.BLACK);

        outcomeTitle = new Label("Winner!",labelStyle);
        outcomeTitle.setFontScale(3.0f, 5.0f);
        outcomeTitle.setPosition(475,400);
        outcomeTitle.setAlignment(Align.center);

        menuButtonLabel = new Label("Menu",labelStyle2);
        menuButtonLabel.setFontScale(1.5f, 1.5f);
        menuButtonLabel.setPosition(475,235);
        menuButtonLabel.setAlignment(Align.center);

        //Button image set up
        buttonTexture = new Texture("planet_button_0.png");
        textureRegion = new TextureRegion(buttonTexture);
        textureRegionDrawable = new TextureRegionDrawable(textureRegion);

        //add different buttons
        exitButton = new ImageButton(textureRegionDrawable);

        //set stage
        stage = new Stage(new ScreenViewport()); //Set up a stage for the ui
        stage.addActor(exitButton);
        stage.addActor(outcomeTitle);
        stage.addActor(menuButtonLabel);
        Gdx.input.setInputProcessor(stage);

        //if instructionButton clicked go to instruction
        exitButton.addListener(new ClickListener() {

            @Override
            public void clicked(InputEvent event, float x, float y) {
                //super.clicked(event, x, y);
                game.setScreen(new Menu(game));

            }
        });

        //playButton position and size
        scaleButtonToScreen(exitButton, 0.1f, 0.1f);
        exitButton.setPosition(400,150);
        exitButton.getImage().setFillParent(true);
    }
    
    /**
     * This is a private function that returns a new label style with the font field set in the
     * constructor and the text colour set through a parameter.
     * @param textColour - The colour to make the label sytle in
     * @return Label.LabelStyle - In built libgdx class of label styles, more information is
     * referenced in see also 
     * @see https://libgdx.badlogicgames.com/ci/nightlies/docs/api/com/badlogic/gdx/scenes/scene2d/ui/Label.LabelStyle.html
     */
    private Label.LabelStyle makeLabelStyle(Color textColour) {
        Label.LabelStyle labelStyle = new Label.LabelStyle();
        labelStyle.font = font;
        labelStyle.fontColor = textColour;
        return labelStyle;
    }
    
    /**
     * This is a method that resizes the button with the screen so that they always appear the right
     * size.
     * @param button - This is an ImageButton that you wish to resize
     * @param widthFactor - This a factor by how much you wish to scale the button in a value of 1
     * would keep it at the same width
     * @param heightFactor - This is factor exactly like widthFactor but for the height
     * @return void
     */
    private void scaleButtonToScreen(ImageButton button, float widthFactor, float heightFactor) {
        button.setSize(Gdx.graphics.getWidth() * widthFactor, Gdx.graphics.getHeight() * heightFactor);
    }

    /**
     * This is a function that comes from the parent class screen, in this class no alterations are
     * made to this function
     * @return void
     * @see https://libgdx.badlogicgames.com/ci/nightlies/docs/api/com/badlogic/gdx/Screen.html
     */
    @Override
    public void show() {

    }

    /**
     * This is the render function that is called on every frame to draw things onto the screen.
     * 
     * @param v - This is the time inbetween each called to this function.
     */
    @Override
    public void render(float v) {
        //Background
        Gdx.gl.glClearColor(0f,0f,0.2f,1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        //draw stage with actors
        stage.act(Gdx.graphics.getDeltaTime());
        stage.draw();

    }

    /**
     * This is a function that comes from the parent class screen, in this class no alterations are
     * made to this function
     * @param width - What width to resize the screen too
     * @param height - What height to resize the screen too
     * @return void
     * @see https://libgdx.badlogicgames.com/ci/nightlies/docs/api/com/badlogic/gdx/Screen.html
     */
    @Override
    public void resize(int i, int i1) {

    }

    /**
     * This is a function that comes from the parent class screen, in this class no alterations are
     * made to this function
     * @return void
     * @see https://libgdx.badlogicgames.com/ci/nightlies/docs/api/com/badlogic/gdx/Screen.html
     */
    @Override
    public void pause() {

    }

    /**
     * This is a function that comes from the parent class screen, in this class no alterations are
     * made to this function
     * @return void
     * @see https://libgdx.badlogicgames.com/ci/nightlies/docs/api/com/badlogic/gdx/Screen.html
     */
    @Override
    public void resume() {

    }

    /**
     * This is a function that comes from the parent class screen, in this class no alterations are
     * made to this function
     * @return void
     * @see https://libgdx.badlogicgames.com/ci/nightlies/docs/api/com/badlogic/gdx/Screen.html
     */
    @Override
    public void hide() {

    }

    /**
     * This is a function that comes from the parent class screen, in this class no alterations are
     * made to this function
     * @return void
     * @see https://libgdx.badlogicgames.com/ci/nightlies/docs/api/com/badlogic/gdx/Screen.html
     */
    @Override
    public void dispose() {

    }
}
