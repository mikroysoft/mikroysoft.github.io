package com.mikroysoft.game;

/** 
 * A enum with all the different colours of progress bars
 */
public enum BarColour {
    YELLOW,
    BLUE,
    PINK
}
