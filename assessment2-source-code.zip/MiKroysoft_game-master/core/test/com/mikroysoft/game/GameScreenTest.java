package com.mikroysoft.game;
import org.junit.*;
import static org.junit.Assert.assertEquals;

public class GameScreenTest {

    @Test
    public void testcreate(){
       // GameScreen gamescreen = new GameScreen();

    }
}
