package com.mikroysoft.game;

/**
 * Enumerates the types of weapon that can be created.
 */
public enum WeaponType {
    NONE,
    BULLET,
    LASER
}
